package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;


import com.javainuse.InputSOATest;
import com.javainuse.OutputSOATest;

@SpringBootApplication
public class SoapClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapClientApplication.class, args);
	}
	
	@Bean
	CommandLineRunner lookup(SOAPConnector soapConnector) {
		return args -> {
			String name = "Tulasi";//Default Name
			if(args.length>0){
				name = args[0];
			}
			InputSOATest request = new InputSOATest();
			request.setTest(name);
			OutputSOATest response =(OutputSOATest) soapConnector.callWebService("http://localhost:8080/javainuse/ws/helloWorldExample", request);
			System.out.println("Got Response As below ========= : ");
			System.out.println("Name : "+response.getResult());
			
		};
	}

}
